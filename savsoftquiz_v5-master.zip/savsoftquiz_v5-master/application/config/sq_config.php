<?php 
		$sq_base_url='';
		$sq_hostname='';
		$sq_dbname='';
		$sq_dbusername='';
		$sq_dbpassword='';
		?>